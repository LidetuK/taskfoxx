import { Suspense } from "react";
import { useRoutes, Routes, Route } from "react-router-dom";
import Home from "./components/home";
import PostTask from "./pages/PostTask";
import Providers from "./pages/Providers";
import Services from "./pages/Services";
import ProviderDashboard from "./pages/ProviderDashboard";
import routes from "tempo-routes";

function App() {
  return (
    <Suspense fallback={<p>Loading...</p>}>
      <>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/post-task" element={<PostTask />} />
          <Route path="/providers" element={<Providers />} />
          <Route path="/services" element={<Services />} />
          <Route path="/services/:category" element={<Services />} />
          <Route path="/provider/dashboard" element={<ProviderDashboard />} />
          <Route path="/provider/tasks" element={<ProviderDashboard />} />
          <Route path="/provider/bids" element={<ProviderDashboard />} />
          <Route path="/provider/earnings" element={<ProviderDashboard />} />
        </Routes>
        {import.meta.env.VITE_TEMPO === "true" && useRoutes(routes)}
      </>
    </Suspense>
  );
}

export default App;
